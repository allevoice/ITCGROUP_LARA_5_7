        <div class="page-loader-wrapper page-loader-wrapper-1"> 
            <div class="loader"> 
                <div class="stick1"></div>                 
                <div class="stick2"></div>                 
                <div class="stick3"></div>                 
                <div class="stick4"></div>                 
                <!--loader-->                 
            </div>             
            <!--page-loader-wrapper-->             
        </div> 
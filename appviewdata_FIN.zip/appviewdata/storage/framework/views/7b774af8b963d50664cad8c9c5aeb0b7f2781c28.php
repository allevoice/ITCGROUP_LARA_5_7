<?php $__env->startSection('title', 'Erreur 404'); ?>


<?php $__env->startSection('datacontent'); ?>


    <div class="main-contentbox" style="height: 10cm">

        <H1>Erreur 404</H1>

        <a href="<?php echo e(route('home')); ?>" class="btn btn-lg btn-info center">Retour</a>

        <span>
            Une Erreur se produit lors de la demande de votre page...Veuillez réessayer
        </span>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.tmpitcg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
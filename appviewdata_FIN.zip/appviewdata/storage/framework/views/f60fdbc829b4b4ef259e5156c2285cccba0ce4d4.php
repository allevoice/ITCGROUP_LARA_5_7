<?php $__env->startSection('title', languesviewdatafixepage('home')); ?>




<?php $__env->startSection('datacontent'); ?>


    <div class="main-contentbox">


    
    <!--===============================================-->
        <!--========= We offer Different Services =========-->
        <!--===============================================-->
        <div class="paddingBox col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="container">
                <div class="row text-center">
                    <?php $__currentLoopData = dataviewhead('1','b'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h2 class="black-font"><?php echo e($show->title); ?></h2>
                        <p class="regular-font"><?php echo e($show->description); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="spacer"></div>

                    <?php if(count($serviv) > 0): ?>
                        <?php $__currentLoopData = $serviv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 imghvr-push-down">
                                <div class="services-box greyBg col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div>
                                        <figure data-effect="pop">
                                            <?php if($lst->blueicone !=NULL): ?>
                                                <img src="<?php echo e(asset('assets/img/services')); ?>/<?php echo e($lst->blueicone); ?>" alt="invest-img" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/img/services/defaultgreen.png')); ?>" alt="invest-img" />
                                            <?php endif; ?>
                                        </figure>
                                        <h4 class="black-color"><?php echo e($lst->title); ?></h4>
                                        <div class="services-info-con">
                                            <div class="services-info">
                                                <div class="services-infoBox">
                                                    <div>
                                                        <figure>
                                                            <?php if($lst->whiteicone !=NULL): ?>
                                                                <img src="<?php echo e(asset('assets/img/services')); ?>/<?php echo e($lst->whiteicone); ?>" alt="invest-imgHover" />
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('assets/img/services/defaultlight.png')); ?>" alt="invest-imgHover" />
                                                            <?php endif; ?>
                                                        </figure>
                                                        <h4 class="white-color"><?php echo e($lst->title); ?></h4>
                                                        <p class="regular-font"><?php echo e(limitemtxt($lst->titleinfo,50)); ?></p>
                                                        <div class="transparent-btn btn1">
                                                            
                                                            <a href="<?php echo e(route('service_details',$lst->codeservice)); ?>">Link</a>
                                                        </div>
                                                    </div>
                                                    <!--services-infoBox-->
                                                </div>
                                                <!--services-info-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--services-box-->
                                </div>
                                <!--col-lg-3-->
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


                <!--row-->
                </div>
                <!--container-->
            </div>
            <!--paddingBox-->
        </div>

    




    <?php if(count($howareu) > 0): ?>
        <!--=====================================-->
            <!--============ Who We Are =============-->
            <!--=====================================-->
            <style>
                @media (max-width: 810px) {
                    .container-fluid {
                        padding-left:0px;

                    }
                    .persoviewhowareu{
                        padding-left:2%;
                    }
                }
                .persoviewhowareu{
                    padding-left:3%;
                }
            </style>
            <div class="container-fluid">
                <div class="pattern pull-left col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color: #000000;">
                    <div  style="background-color: #000000;" >

                        <?php $__currentLoopData = $howareu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $howareuget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="who-we-are pull-left col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="persoviewhowareu">
                                        <h2><?php echo e($howareuget->title); ?></h2>
                                        <p><?php echo e($howareuget->description); ?> </p>
                                        <div class="transparent-btn pull-left">
                                            <a href="<?php echo e($howareuget->link); ?>" target="_blank">Join Now</a>
                                        </div>
                                    </div>
                                    <!--who-we-are-->
                                </div>
                                <!--row-->
                            </div>

                            <div class="who-we-are-img">
                                <img src="<?php echo e(asset('assets/img/whoareuimg')); ?>/<?php echo e($howareuget->backimg); ?>" alt="who-we-are-img"/>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--container-->
                    </div>

                    <!--pattern-->
                </div>
            </div>

    <?php endif; ?>


    <?php if(count($bringing) > 0): ?>
        <!--====================================-->
            <!--========= Business Meeting =========-->
            <!--====================================-->
            <div class="paddingBox col-lg-12 col-md-12 col-sm-12 col-xs-12 " style="z-index: 999;background-color: #ffffff">
                <div class="container">
                    <div class="row">
                        <?php $__currentLoopData = $bringing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bringviwelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-center col-lg-5 col-md-5 col-sm-4 col-xs-3">
                                <div class="logo-background">
                                    <figure class="business-meeting-img">
                                        <img src="<?php echo e(asset('assets/img/logo')); ?>/<?php echo e($bringviwelist->backimg); ?>" alt="business-meeting" class="pull-right img-responsive"/>
                                    </figure>
                                    <!--logo-background-->
                                </div>
                                <!--text-center-->
                            </div>
                            <div class="business-box col-lg-7 col-md-7 col-sm-8 col-xs-9 divtextcss" style="margin-top: 0px">
                                <div>
                                    <?php echo $bringviwelist->description; ?>

                                </div>


                                <div class="transparent-btn">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo e($bringviwelist->link); ?>" style="text-align: center"  target="_blank">Contact Us</a>
                                    </div>
                                </div>
                                <!--business-box-->
                            </div>
                            <!--row-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <!--container-->
                </div>
                <!--paddingBox-->
            </div>

    <?php endif; ?>

    <!--main-contentbox-->
    </div>



    <?php if(count($helpingview) > 0): ?>
        <!--=====================================-->
        <!--========= Bringing new look =========-->
        <!--=====================================-->
        <div class="text-center col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="row">

                <?php $__currentLoopData = $helpingview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $helpingviwelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <aside class="business-imagebox col-lg-4 col-md-4 col-sm-7 col-xs-12 ">
                        <div class="row">
                            <figure>
                                <img alt="business-quality" src="<?php echo e(asset('assets/img/logo')); ?>/<?php echo e($helpingviwelist->backimghelp); ?>">
                            </figure>
                            <h3 class="caption-heading"><?php echo e($helpingviwelist->title); ?></h3>
                            <div class="caption">
                                <div class="caption-text">
                                    <h3><?php echo e($helpingviwelist->title); ?></h3>
                                    <p class="regular-font"><?php echo e($helpingviwelist->description); ?></p>
                                    <!-- // <div class="transparent-btn"><a href="#">Read More</a></div> //-->
                                    <!-- caption-text-->
                                </div>
                                <!--caption-->
                            </div>
                            <!--row-->
                        </div>
                        <!--business-imagebox-->
                    </aside>




                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </div>
            <!--text-center-->
        </div>
    <?php endif; ?>




    <?php if(count($skill) > 0): ?>

        <!--=====================================-->
        <!--============= Skill Level ===========-->
        <!--=====================================-->
        <div class="paddingBox col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="container">
                <div class="row">



                    <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skilllist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <aside class="skill-level col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                <div class="col-lg-4 col-md-12 col-sm-12 stat-count text-left bold-font" style="margin-left: -10%"><?php echo e($skilllist->numberskill); ?></div>
                                <div class="col-lg-4 col-md-12 col-sm-12 text-right" style="margin-left: 10%">
                                    <h4 class="black-color"><span ><?php echo e($skilllist->title); ?></span></h4>
                                </div>
                                <!--skill-level-->
                            </aside>
                            <!--col-lg-3-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!--paddingBox-->
            </div>
            <!--main-contentbox-->
        </div>

    <?php endif; ?>





    <?php if(count($partner) > 0): ?>
        <!--=====================================-->
        <!--============== Partners =============-->
        <!--=====================================-->
        <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="container">
                <div class="row">
                    <aside class="paddingBox border-top col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="partner-heading col-lg-2 col-md-3 col-sm-12 col-xs-12">Our
                            <br>
                            <span class="light-font">Business</span>
                            <br>
                            Partners
                            <!--partner-heading-->
                        </div>

                        <div class="partners col-lg-10 col-md-12 col-sm-12 col-xs-12">



                            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnerlst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <aside class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                    <div class="partner-logos col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>
                                    <a href="<?php echo e($partnerlst->linkpartner); ?>" title="<?php echo e($partnerlst->titlepartner); ?>" target="_blank">
                                        <img src="<?php echo e(asset('assets/img/partners/')); ?>/<?php echo e($partnerlst->imgpartner); ?>" alt="" class="img-thumbnail" width="100%"/>
                                    </a>
                                </span>
                                        <!--partner-logos-->
                                    </div>
                                    <!--col-lg-3-->
                                </aside>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!--partners-->
                        </div>

                        <div class="col-lg-10 col-md-9 col-sm-12 col-xs-12">
                            <a href="<?php echo e(route('parnerliste')); ?>" class="btn btn-sm btn-primary">More Partners</a>
                        </div>
                        <!--paddingBox-->
                    </aside>
                    <!--row-->
                </div>
                <!--container-->
            </div>
            <!--col-lg-12-->
        </div>
        <!--main-contentbox-->

        <?php endif; ?>











        </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.tmpitcg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
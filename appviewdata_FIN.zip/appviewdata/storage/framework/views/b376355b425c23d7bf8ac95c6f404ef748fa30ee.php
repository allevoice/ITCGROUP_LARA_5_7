<!--=====================================-->
<!--============== Banner ===============-->
<!--=====================================-->



<?php if(isset($slideview)): ?>

    <div id="carousel-example-generic" class="carousel slide colorback" data-ride="carousel" >

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php $__currentLoopData = $slideview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item <?php echo e($lst->level == 1 ? 'active' : ''); ?>">
                <div  class="pull-right">
                    <?php if($lst->backimgview != NULL): ?>
                        <img src="<?php echo e(asset('assets/img/slideshow/')); ?>/<?php echo e($lst->backimgview); ?>" class="imgbanner"/>
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/slideshow/default.jpg')); ?>" class="imgbanner"/>
                    <?php endif; ?>
                </div>

                <div class="viewlogoimg">
                    <?php if($lst->logoview != NULL): ?>
                        <img src="<?php echo e(asset('assets/img/slideshow/')); ?>/<?php echo e($lst->logoview); ?>" class="pull-left imglogo"  alt="small-logo" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/logo/small-logo.png')); ?>" class="pull-left imglogo"  alt="small-logo" />
                    <?php endif; ?>
                </div>


                <div class="carousel-caption img_carousel">
                    <h1><?php echo e($lst->title); ?></h1>
                    <p><?php echo e($lst->description); ?></p>
                    <div class="banner-btn transparent-btn">
                        <a href="<?php echo e($lst->link); ?>" target="_blank">Contact Us Now</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









    </div>

    <div class="explore-services BlueBg semibold-font" id="explore">Explore the
        services
        <figure class="bounce">
            <img src="<?php echo e(asset('assets/img/logo/arrow-down.png')); ?>" alt="arrow" />
        </figure>
        <!--explore-services-->
    </div>
</div>

    <?php endif; ?>




<!--=====================================-->
<!--============ Navigation =============-->
<!--=====================================-->
<div class="greyBg header-con col-lg-12 col-md-12 col-sm-12 col-xs-12" id="headerCon">
    <div class="container">
        <div class="row">
            <aside class="header col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="logo pull-left">

                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" alt="logo" />
                    </a>
                </div>
                <div class="clearfix showmb"></div>
                <nav class="navbar navbar-default pull-right">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <!--navbar-header-->
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="clearfix showmb"></div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <div class="row">
                                    <ul class="nav navbar-nav pull-right" >
                                        
                                        <li class="<?php if(url()->current() == route('home')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('home')); ?>"><?php echo e(languesviewdatafixepage('home')); ?></a>
                                        </li>
                                        <li class="<?php if(url()->current() == route('about')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('about')); ?>"><?php echo e(languesviewdatafixepage('about')); ?></a>
                                        </li>
                                        <li class="<?php if(url()->current() == route('services')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('services')); ?>"><?php echo e(languesviewdatafixepage('service')); ?></a>
                                        </li>

                                        <li class="<?php if(url()->current() == route('projects')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('projects')); ?>"><?php echo e(languesviewdatafixepage('project')); ?></a>
                                        </li>

                                        <li class="<?php if(url()->current() == route('blog')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('blog')); ?>"><?php echo e(languesviewdatafixepage('blog')); ?></a>
                                        </li>


                                        <li class="<?php if(url()->current() == route('contact')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('contact')); ?>"><?php echo e(languesviewdatafixepage('contact')); ?></a>
                                        </li>



                                        
                                            
                                                
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                        <li>
                                            <?php if(Session::has('paneladmin') != NULL): ?>
                                                <a href="<?php echo e(route('adminpage')); ?>" class="btn btn-sm btn-danger square-btn-adjust"><span class="fa fa-eye"></span></a>
                                            <?php endif; ?>
                                        </li>


                                        <style>
                                            .select-style {
                                                padding: 0;
                                                margin: 0;
                                                border: 1px solid #ccc;
                                                width: 90px;
                                                border-radius: 3px;
                                                overflow: hidden;
                                                background-color: #fff;
                                                background: #fff;
                                                position: relative;
                                            }

                                            .select-style select {
                                                padding: 5px 8px;
                                                border: none;
                                                width:100%;
                                                box-shadow: none;
                                                background-color: transparent;
                                                background-image: none;
                                                -webkit-appearance: none;
                                                -moz-appearance: none;
                                                appearance: none;
                                            }

                                            .select-style:after {
                                                top: 50%;
                                                left: 85%;
                                                border: solid transparent;
                                                content: " ";
                                                height: 0;
                                                width: 0;
                                                position: absolute;
                                                pointer-events: none;
                                                border-color: rgba(0, 0, 0, 0);
                                                border-top-color: #000000;
                                                border-width: 5px;
                                                margin-top: -2px;
                                                z-index: 100;
                                            }

                                            .select-style select:focus {
                                                outline: none;
                                            }
                                        </style>



                                    </ul>




                                    <!--row-->
                                </div>
                                <!--collapse-->


                            </div>
                            <!--row-->
                        </div>

                        <!--container-fluid-->
                    </div>
                    <!--navbar-->





                </nav>
                <!--header-->
            </aside>
            <!--row-->
        </div>
        <!--container-->
    </div>
    <!--greyBg-->
</div>


